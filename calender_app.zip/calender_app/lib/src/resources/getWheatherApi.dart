import 'dart:async';
import 'package:calender_app/src/functions/errorHandling.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';

Future<dynamic> getWheather(
  BuildContext context,
  int type,
  int plan,
  int slot,
) async {
  var url = "https://us-central1-washle.cloudfunctions.net/getPrice";
  // print("url: $url");

  Map<String, dynamic> body = {
    "type": type,
    "plan": plan,
    "slot": slot,
    // widget.sid, // shopkeeper id
  };

  http.Response response;
  // try {
  response = await http.post(
    url,
    body: json.encode(body),
    headers: {
      "Content-Type": 'application/json',
      // "Authorization": "Bearer $userToken",
    },
    // params
  ).catchError((e) {
    // print("eroro here is 0: $e");
    errorDialog(
      context,
      "Oops",
      "Please check you are connected to internet",
    );
    return false;
  });

  // print("status: ${response.statusCode}");
  // print("body: ${response.body}");
  // print("request Type: ${response.request}");

  if (response.statusCode == 200) {
    return response.body;
  }
  return false;
}
