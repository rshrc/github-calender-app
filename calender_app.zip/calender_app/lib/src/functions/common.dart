double cHeight, cWidth;
int theme = 0;
