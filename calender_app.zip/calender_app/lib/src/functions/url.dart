import 'package:url_launcher/url_launcher.dart';

privacyPolicy() async {
  // Android
  String uri = "https://www.washle1.co.in/privacy-policy.html";
  if (await canLaunch(uri)) {
    await launch(uri);
  }
}
